package com.example.mvvm.jetpackcomposepilipplackner

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

class BasicExample2 : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
         /*   Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Green),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceAround

            )*/
            Row(
                modifier = Modifier
                    .width(300.dp)
                   // .height(300.dp)
                    .fillMaxHeight(.5f )
                    .fillMaxSize()
                    .background(Color.Green),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically

            )

            {
                Text(text = "Hello")
                Text(text = "World")
                Text(text = "Hello")
            }
        }
    }
}

