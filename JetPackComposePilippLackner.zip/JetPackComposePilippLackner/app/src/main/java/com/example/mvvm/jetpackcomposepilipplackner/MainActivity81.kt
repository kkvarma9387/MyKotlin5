package com.example.mvvm.jetpackcomposepilipplackner

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// lazy column example it will load all 5000 list items once when load the list
class MainActivity81 : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val scrollState = rememberScrollState()

            LazyColumn {
               items(5000){
                   Text(
                       text = "Item $it",
                       fontSize = 24.sp,
                       fontWeight = FontWeight.Bold,
                       textAlign = TextAlign.Center,
                       modifier = Modifier
                           .fillMaxWidth()
                           .padding(vertical = 24.dp)

                   )
               }

            }
        }
    }
}
