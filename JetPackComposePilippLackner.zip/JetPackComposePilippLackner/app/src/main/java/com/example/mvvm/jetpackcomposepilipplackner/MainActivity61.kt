package com.example.mvvm.jetpackcomposepilipplackner

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import kotlin.random.Random

class MainActivity61 : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Column(Modifier.fillMaxSize()) {
                val colorState = remember { //Keeps a value over time
                    mutableStateOf(Color.Yellow) //Observable state holder
                }

                ColorBox(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxSize()
                ) {
                    colorState.value = it // update state color (it) when click
                }

                Box(
                    modifier = Modifier
                        .background(colorState.value)
                        .weight(1f)
                        .fillMaxSize()

                )
            }

        }
    }
}

@SuppressLint("UnrememberedMutableState")
@Composable
fun ColorBox(
    modifier: Modifier,
    updateColor: (Color) -> Unit // callback function to change the state of the box  --- it wont return any value so unit
) {

    Box(modifier = modifier
        .background(Color.Red)
        .clickable { // update when click
            updateColor(
                Color(
                    Random.nextFloat(),
                    Random.nextFloat(),
                    Random.nextFloat(),
                    1f
                )
            )
        }
    )
}