package com.example.mvvm.jetpackcomposepilipplackner

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

class StateSimpleExampleBy : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var count by rememberSaveable {
                mutableStateOf(0)
            }
            StateLessCounter(count, onIncrement = { count++ })
        }
    }

    @Composable
    private fun StateLessCounter(
        count: Int,
        onIncrement: () -> Unit
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            if (count > 0) {
                Text(text = "You have had $count numbers.")
            }
            Button(
                onClick = onIncrement,
                modifier = Modifier.padding(8.dp),
                enabled = count < 10
            ) {
                Text(text = "Add Me")
            }
            Text(
                text = "Click Me $count",

                modifier = Modifier.clickable {
                    onIncrement
                }, Color.Red

            )
        }
    }
}


